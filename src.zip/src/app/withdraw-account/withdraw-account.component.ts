import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-withdraw-account',
  templateUrl: './withdraw-account.component.html',
  styleUrls: ['./withdraw-account.component.css']
})
export class WithdrawAccountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
