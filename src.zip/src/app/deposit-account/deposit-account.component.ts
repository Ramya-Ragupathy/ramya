import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deposit-account',
  templateUrl: './deposit-account.component.html',
  styleUrls: ['./deposit-account.component.css']
})
export class DepositAccountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
