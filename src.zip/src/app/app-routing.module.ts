import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router';
import { CreateAccountComponent } from './create-account/create-account.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositAccountComponent } from './deposit-account/deposit-account.component';
import { WithdrawAccountComponent } from './withdraw-account/withdraw-account.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { PrintTransactionComponent } from './print-transaction/print-transaction.component';
import {FormsModule} from '@angular/forms';

const routes:Routes=[
  {
    path:"Create-Account",
    component:CreateAccountComponent
  },
  {
    path:"Show-Balance",
    component:ShowBalanceComponent
  },
  {
    path:"Deposit-Amount",
    component:DepositAccountComponent
  },
  {
    path:"Withdraw-Amount",
    component:WithdrawAccountComponent
  },
  {
    path:"Fund-Transfer",
    component:FundTransferComponent
  },
  {
    path:"Print-Transaction",
    component:PrintTransactionComponent
  }
  ]
@NgModule({
  imports: [RouterModule.forRoot(routes),CommonModule,FormsModule],
  exports:[RouterModule]
})
export class AppRoutingModule { }
